<script setup>
import CounterButton from './components/CounterButton.vue';

</script>

<template>
  <CounterButton />
  <CounterButton />
  <CounterButton />
  <CounterButton />

</template>

<style scoped></style>
